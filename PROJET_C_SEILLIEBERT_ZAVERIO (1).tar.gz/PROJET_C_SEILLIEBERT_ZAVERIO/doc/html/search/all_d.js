var searchData=
[
  ['win_5fsound_0',['win_sound',['../display_8h.html#a6431904080006328743e58e44673e6ce',1,'win_sound(Sounds *sounds):&#160;display.c'],['../display_8c.html#a6431904080006328743e58e44673e6ce',1,'win_sound(Sounds *sounds):&#160;display.c']]]
];
