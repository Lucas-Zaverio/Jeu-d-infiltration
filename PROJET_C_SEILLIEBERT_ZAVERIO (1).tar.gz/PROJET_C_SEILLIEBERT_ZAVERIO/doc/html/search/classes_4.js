var searchData=
[
  ['relic_0',['Relic',['../struct_relic.html',1,'']]],
  ['relics_1',['Relics',['../struct_relics.html',1,'']]]
];
