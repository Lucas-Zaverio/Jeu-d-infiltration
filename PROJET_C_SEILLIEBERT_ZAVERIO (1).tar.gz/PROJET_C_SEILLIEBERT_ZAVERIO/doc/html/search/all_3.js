var searchData=
[
  ['free_5fgame_0',['free_game',['../game_8h.html#a98bb68f0ee0b77fbd9d7c56957190c9d',1,'free_game(Game *game):&#160;game.c'],['../game_8c.html#a98bb68f0ee0b77fbd9d7c56957190c9d',1,'free_game(Game *game):&#160;game.c']]],
  ['free_5fguardians_1',['free_guardians',['../guardian_8h.html#aa47a54f5ebbd1e1e0f0e044c31dd3e23',1,'free_guardians(Guardians *guardians):&#160;guardian.c'],['../guardian_8c.html#aa47a54f5ebbd1e1e0f0e044c31dd3e23',1,'free_guardians(Guardians *guardians):&#160;guardian.c']]],
  ['free_5fkeys_2',['free_keys',['../keys_8h.html#aea6166a40d2399fc009fd541d9fa9449',1,'free_keys(Keys *keys):&#160;keys.c'],['../keys_8c.html#aea6166a40d2399fc009fd541d9fa9449',1,'free_keys(Keys *keys):&#160;keys.c']]],
  ['free_5frelics_3',['free_relics',['../relic_8h.html#a0ffca162dac21489cab0e703e4ae1b56',1,'free_relics(Relics *relics):&#160;relic.c'],['../relic_8c.html#a0ffca162dac21489cab0e703e4ae1b56',1,'free_relics(Relics *relics):&#160;relic.c']]],
  ['free_5fsounds_4',['free_sounds',['../display_8h.html#aed74d41b28d0555df30d35bd0674693b',1,'free_sounds(Sounds *sounds):&#160;display.c'],['../display_8c.html#aed74d41b28d0555df30d35bd0674693b',1,'free_sounds(Sounds *sounds):&#160;display.c']]]
];
