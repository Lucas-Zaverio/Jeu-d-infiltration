var searchData=
[
  ['panic_5fsound_0',['panic_sound',['../display_8h.html#a7e3e2d50ef320c14417649d69e6ffad9',1,'panic_sound(Sounds *sounds):&#160;display.c'],['../display_8c.html#a7e3e2d50ef320c14417649d69e6ffad9',1,'panic_sound(Sounds *sounds):&#160;display.c']]],
  ['play_5fgame_1',['play_game',['../game_8h.html#a14a887ba94f32d55095d989382b3cacb',1,'play_game(Game *game):&#160;game.c'],['../game_8c.html#a14a887ba94f32d55095d989382b3cacb',1,'play_game(Game *game):&#160;game.c']]],
  ['player_5fon_5fmana_2',['player_on_mana',['../player_8h.html#a33487d8b1c667a5f2afaee952fc60f65',1,'player_on_mana(Player *player, Ground *ground):&#160;player.c'],['../player_8c.html#a33487d8b1c667a5f2afaee952fc60f65',1,'player_on_mana(Player *player, Ground *ground):&#160;player.c']]]
];
