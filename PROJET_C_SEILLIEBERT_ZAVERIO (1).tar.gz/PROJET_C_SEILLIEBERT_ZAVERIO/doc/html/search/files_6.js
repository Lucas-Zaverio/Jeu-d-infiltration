var searchData=
[
  ['relic_2ec_0',['relic.c',['../relic_8c.html',1,'']]],
  ['relic_2eh_1',['relic.h',['../relic_8h.html',1,'']]]
];
