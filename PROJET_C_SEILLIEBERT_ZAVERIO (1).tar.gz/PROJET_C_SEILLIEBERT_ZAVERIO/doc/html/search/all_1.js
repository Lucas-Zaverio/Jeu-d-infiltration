var searchData=
[
  ['check_5fcollision_0',['check_collision',['../position_8h.html#a82a040cf71e621d418ebbd4c7fba381d',1,'check_collision(Position position, Ground ground):&#160;position.c'],['../position_8c.html#a82a040cf71e621d418ebbd4c7fba381d',1,'check_collision(Position position, Ground ground):&#160;position.c']]],
  ['check_5feucledian_5fdistance_1',['check_eucledian_distance',['../position_8h.html#a3cc158f723fd4edd0c0cf41895c4c779',1,'check_eucledian_distance(Position position, Position target, double distance):&#160;position.c'],['../position_8c.html#a3cc158f723fd4edd0c0cf41895c4c779',1,'check_eucledian_distance(Position position, Position target, double distance):&#160;position.c']]],
  ['check_5fpanic_2',['check_panic',['../guardian_8h.html#a34fe560fa976588e8f272c7a812febce',1,'check_panic(Guardians *guardians, Player player, Ground *ground, double chrono):&#160;guardian.c'],['../guardian_8c.html#a34fe560fa976588e8f272c7a812febce',1,'check_panic(Guardians *guardians, Player player, Ground *ground, double chrono):&#160;guardian.c']]]
];
