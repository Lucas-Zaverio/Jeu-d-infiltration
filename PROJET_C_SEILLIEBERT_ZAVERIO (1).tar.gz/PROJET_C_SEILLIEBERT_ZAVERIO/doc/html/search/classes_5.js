var searchData=
[
  ['scorechrono_0',['ScoreChrono',['../struct_score_chrono.html',1,'']]],
  ['scoremana_1',['ScoreMana',['../struct_score_mana.html',1,'']]],
  ['sounds_2',['Sounds',['../struct_sounds.html',1,'']]]
];
