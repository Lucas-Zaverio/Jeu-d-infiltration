var searchData=
[
  ['scorechrono_0',['ScoreChrono',['../struct_score_chrono.html',1,'']]],
  ['scoremana_1',['ScoreMana',['../struct_score_mana.html',1,'']]],
  ['skill_2',['Skill',['../player_8h.html#a53d804c2b0df9ad8b7f77f8c1ee82392',1,'player.h']]],
  ['skill_5fremove_5fsound_3',['skill_remove_sound',['../display_8h.html#ac84c8e4a21132e2104cacfd9944e1ace',1,'skill_remove_sound(Sounds *sounds):&#160;display.c'],['../display_8c.html#ac84c8e4a21132e2104cacfd9944e1ace',1,'skill_remove_sound(Sounds *sounds):&#160;display.c']]],
  ['skill_5fsound_4',['skill_sound',['../display_8h.html#a6f30a813779fb376f854b908b61518d5',1,'skill_sound(Sounds *sounds):&#160;display.c'],['../display_8c.html#a6f30a813779fb376f854b908b61518d5',1,'skill_sound(Sounds *sounds):&#160;display.c']]],
  ['sounds_5',['Sounds',['../struct_sounds.html',1,'']]],
  ['squaretype_6',['SquareType',['../ground_8h.html#a914440062dc2a740cf4894b3b84a1ba5',1,'ground.h']]],
  ['stealth_20game_7',['Stealth Game',['../index.html',1,'']]],
  ['stop_5fplayer_8',['stop_player',['../player_8h.html#a20d6a05c2a8673da1d0820494d15e7d8',1,'stop_player(Player *player):&#160;player.c'],['../player_8c.html#a20d6a05c2a8673da1d0820494d15e7d8',1,'stop_player(Player *player):&#160;player.c']]]
];
