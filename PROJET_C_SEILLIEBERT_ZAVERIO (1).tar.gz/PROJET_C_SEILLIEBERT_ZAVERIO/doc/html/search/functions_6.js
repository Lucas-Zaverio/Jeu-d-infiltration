var searchData=
[
  ['leaderboard_5fadd_5fscore_0',['leaderboard_add_score',['../leaderboard_8h.html#a20f1b0ba8c1648779a44c035f888c76d',1,'leaderboard_add_score(Leaderboard *leaderboard, char *name, double chrono, int mana):&#160;leaderboard.c'],['../leaderboard_8c.html#a20f1b0ba8c1648779a44c035f888c76d',1,'leaderboard_add_score(Leaderboard *leaderboard, char *name, double chrono, int mana):&#160;leaderboard.c']]],
  ['loose_5fsound_1',['loose_sound',['../display_8h.html#a1276f793e540d1d8ae382ca6e35e4174',1,'loose_sound(Sounds *sounds):&#160;display.c'],['../display_8c.html#a1276f793e540d1d8ae382ca6e35e4174',1,'loose_sound(Sounds *sounds):&#160;display.c']]]
];
