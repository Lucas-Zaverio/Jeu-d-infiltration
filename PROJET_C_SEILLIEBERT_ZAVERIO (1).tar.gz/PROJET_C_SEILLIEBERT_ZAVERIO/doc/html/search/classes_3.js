var searchData=
[
  ['player_0',['Player',['../struct_player.html',1,'']]],
  ['position_1',['Position',['../struct_position.html',1,'']]]
];
