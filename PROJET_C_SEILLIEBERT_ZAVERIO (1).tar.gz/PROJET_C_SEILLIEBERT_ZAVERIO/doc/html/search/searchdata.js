var indexSectionsWithContent =
{
  0: "acdfgiklmoprsw",
  1: "gklprs",
  2: "dgklmpr",
  3: "acdfgilmoprsw",
  4: "dgs",
  5: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "enums",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Enumerations",
  5: "Pages"
};

