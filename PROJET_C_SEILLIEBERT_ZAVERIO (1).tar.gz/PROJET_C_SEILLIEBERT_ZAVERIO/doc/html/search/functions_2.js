var searchData=
[
  ['display_5fgame_0',['display_game',['../display_8h.html#a9cfefb445fb9e870c945dfd65adc798f',1,'display_game(Ground ground, Player player, Guardians guardians, double chrono):&#160;display.c'],['../display_8c.html#a9cfefb445fb9e870c945dfd65adc798f',1,'display_game(Ground ground, Player player, Guardians guardians, double chrono):&#160;display.c']]],
  ['display_5floose_1',['display_loose',['../display_8h.html#a788b965b50d14bfb5b457b5664440803',1,'display_loose(double chrono, int mana_spent, Leaderboard leaderboard):&#160;display.c'],['../display_8c.html#a788b965b50d14bfb5b457b5664440803',1,'display_loose(double chrono, int mana_spent, Leaderboard leaderboard):&#160;display.c']]],
  ['display_5fstart_2',['display_start',['../display_8h.html#abbc7ad418f346dd67e755ecd42090176',1,'display_start(char *message, Sounds sounds):&#160;display.c'],['../display_8c.html#abbc7ad418f346dd67e755ecd42090176',1,'display_start(char *message, Sounds sounds):&#160;display.c']]],
  ['display_5fwin_3',['display_win',['../display_8h.html#aec2f3cb051fc6281c97b8e50f3a8926f',1,'display_win(double chrono, int mana_spent, Leaderboard leaderboard, int desactive_input):&#160;display.c'],['../display_8c.html#a49fcd87d4cb4197ebf42ff405b0ae360',1,'display_win(double chrono, int mana_spent, Leaderboard leaderboard, int desactive):&#160;display.c']]]
];
