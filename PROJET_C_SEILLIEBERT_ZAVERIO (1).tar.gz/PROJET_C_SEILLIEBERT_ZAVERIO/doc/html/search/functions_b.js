var searchData=
[
  ['skill_5fremove_5fsound_0',['skill_remove_sound',['../display_8h.html#ac84c8e4a21132e2104cacfd9944e1ace',1,'skill_remove_sound(Sounds *sounds):&#160;display.c'],['../display_8c.html#ac84c8e4a21132e2104cacfd9944e1ace',1,'skill_remove_sound(Sounds *sounds):&#160;display.c']]],
  ['skill_5fsound_1',['skill_sound',['../display_8h.html#a6f30a813779fb376f854b908b61518d5',1,'skill_sound(Sounds *sounds):&#160;display.c'],['../display_8c.html#a6f30a813779fb376f854b908b61518d5',1,'skill_sound(Sounds *sounds):&#160;display.c']]],
  ['stop_5fplayer_2',['stop_player',['../player_8h.html#a20d6a05c2a8673da1d0820494d15e7d8',1,'stop_player(Player *player):&#160;player.c'],['../player_8c.html#a20d6a05c2a8673da1d0820494d15e7d8',1,'stop_player(Player *player):&#160;player.c']]]
];
