var searchData=
[
  ['add_5fskill_0',['add_skill',['../player_8h.html#a53e1f353cc3a0b9e2c0539488c2741f6',1,'add_skill(Player *player, Skill skill, Ground *ground):&#160;player.c'],['../player_8c.html#a53e1f353cc3a0b9e2c0539488c2741f6',1,'add_skill(Player *player, Skill skill, Ground *ground):&#160;player.c']]]
];
